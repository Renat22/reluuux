<?php
session_start();
define("MAX_IDLE_TIME", 1);
function getOnlineUsers(){
    if ( $directory_handle = opendir( session_save_path() ) ) {
        $count = 0;
        while ( false !== ( $file = readdir( $directory_handle ) ) ) {
            if($file != '.' && $file != '..'){
                if(time()- filemtime(session_save_path() . '' . $file) < MAX_IDLE_TIME * 60) {
                    $count++;
                }
            } }
        closedir($directory_handle);
        return $count;
    } else {
        return false;
    }}
echo getOnlineUsers();
?>
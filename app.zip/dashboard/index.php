<div style="text-align: center;margin: 40px;">
	<h1>страница 1 (DASHBOARD)</h1>
	Видеооо:<br>
	<iframe width="560" height="315" src="https://www.youtube.com/embed/VEcAAUEQ6rs?autoplay=1" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
	<br><br>
	<i class="fab fa-500px"></i>
	<i class="fab fa-500px"></i>
	<i class="fab fa-500px"></i>
	<i class="fab fa-500px"></i>
	<i class="fab fa-500px"></i>
	<i class="fab fa-500px"></i>
	<i class="fab fa-500px"></i>
	<i class="fab fa-500px"></i>
	<i class="fab fa-500px"></i>
	<i class="fab fa-500px"></i>
	<i class="fab fa-500px"></i>
	<i class="fab fa-500px"></i>
	<br><br>
	<img src="https://s00.yaplakal.com/pics/pics_original/5/3/3/13224335.jpg" style="width: 560px;"></p>
	<script>document.title = "dashboard";</script>
</div>